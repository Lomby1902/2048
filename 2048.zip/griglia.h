#ifndef GRIGLIA_H
#define GRIGLIA_H

#include <stdio.h>
#include "linea.h"
#include "classifica.h"


//griglia
struct nodo_griglia{
        linea linea;
	struct nodo_griglia* next;
	struct nodo_griglia* prec;
};

struct griglia{
	int parz;
	giocatore player;
	struct nodo_griglia* head;
	struct nodo_griglia* tail;
};

typedef struct griglia* griglia;





griglia crea_griglia();

int popola_griglia(griglia my_griglia,int n,giocatore player);

void stampa_griglia(griglia my_griglia,int n,int punteggio);

int griglia_piena(griglia my_griglia, int n);

void inserisci_random_griglia(griglia my_griglia,int n);

int muovi_destra_griglia(griglia my_griglia, int n);

int muovi_sinistra_griglia(griglia my_griglia,int n);

int muovi_sopra(griglia my_griglia,int n);

int muovi_sotto(griglia my_griglia,int n);

int controlla_colonne(griglia my_griglia);

int controlla_mosse(griglia my_griglia,int n);

int get_punteggio(griglia my_griglia);

int elimina_griglia(griglia my_griglia);




#endif


